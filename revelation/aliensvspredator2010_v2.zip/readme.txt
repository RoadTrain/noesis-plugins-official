Alien vs. Predator Plugin

This plugin allows for simple viewing of mesh and skeleton data.

The included bms script has been modified to output the chunk type as the file extension, and to keep the data headers intact so that files can be "properly" verified.  File names have been added for some of the known file types, namely RSCF which is assumed to stand for Resource File, HANM which are animtions, HSKN which is skeleton data, HSKL which associates RSCF file with their HSKN counter part, and HSBB which is bounding box information for skeletons.

Currently only mesh RSCF files are supported by the plugin.

Loading a supported RSCF file will only load the mesh data.

To load a mesh and skeleton, load a HSKL file.  During load the relevant RSCF and HSKN files will be loaded automatically if found within the same directory as the HSKL file.  Otherwise file load dialogs will allow for choosing corresponding files to load.

Depending on the tool you decide to import exported data into, the texture coordinates may need to be flipped using the option in the Noesis export dialog.  i will work on fixing the orientation when i get the chance.

Let me know if there are any meshes that load incorrectly.

A number of the models use "fix up" and other extra bones to aid in resolving joint orientation issues that would arise, as such moving some joints may not deform the mesh as assumed without taking these into account.

Animation support is planned as well.
